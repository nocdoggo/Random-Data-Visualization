import pandas as pd

print(pd.__version__)
